# PlayMix TV para iPhone / iPad (SwiftUI)

Versión iOS nativa de PlayMix TV. Vive en la carpeta `ios/` del mismo repo que la app Android.

## Cómo compilar (sin Mac)
1. Copia `ios/` y `.github/workflows/build-ios.yml` a tu carpeta del repo y haz Commit + Push.
2. En GitHub → Actions → "Build iOS (IPA sin firmar)" (se lanza solo o con "Run workflow").
3. Descarga el artefacto `PlayMixTV-ipa` → `PlayMixTV.ipa`.
4. Instálalo con AltStore, Sideloadly o similar (firma con tu Apple ID). Para TestFlight/App Store se necesita cuenta Apple Developer (99 USD/año).

Con Mac: instala XcodeGen (`brew install xcodegen`), ejecuta `xcodegen generate` dentro de `ios/` y abre `PlayMixTV.xcodeproj`.

## Incluye
Login con código de acceso (panel valtecno.cl → credenciales Xtream; sesión guardada en el Keychain de iOS), TV en vivo, películas, series con temporadas, favoritos e historial por cuenta, búsqueda global, control parental (PIN + categorías bloqueadas), modo Niños, multi-pantalla de 4 canales, AirPlay e Imagen en Imagen.

## Pendiente / limitaciones
- iOS no reproduce MKV/AVI de forma nativa; solo HLS (.m3u8), MP4/MOV. Para más formatos habría que integrar VLCKit o similar.
- Sin Chromecast (en iPhone se usa AirPlay), sin sección Radio, sin auto-actualización (iOS no lo permite fuera de la App Store).
