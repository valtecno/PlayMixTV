import SwiftUI

extension Color {
    init(hex: UInt32) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: 1)
    }
}

enum Theme {
    static let orange = Color(hex: 0xFF8A3D)
    static let pink = Color(hex: 0xFF3D8B)
    static let purple = Color(hex: 0x8B3DFF)

    static let brand = LinearGradient(colors: [orange, pink, purple],
                                      startPoint: .leading, endPoint: .trailing)

    static let background = LinearGradient(
        colors: [Color(hex: 0x2A0A4A), Color(hex: 0x120522), .black],
        startPoint: .top, endPoint: .bottom)
}

/// Fondo "Streaming vibrante": degradado morado -> negro con brillo rosa/naranja.
struct BrandBackground: View {
    var body: some View {
        ZStack {
            Theme.background
            RadialGradient(colors: [Theme.pink.opacity(0.35), .clear],
                           center: .topTrailing, startRadius: 10, endRadius: 380)
            RadialGradient(colors: [Theme.orange.opacity(0.18), .clear],
                           center: .bottomLeading, startRadius: 10, endRadius: 320)
        }
        .ignoresSafeArea()
    }
}

struct GlassCard: ViewModifier {
    var radius: CGFloat = 16
    func body(content: Content) -> some View {
        content
            .background(Color.white.opacity(0.08))
            .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous)
                .stroke(Color.white.opacity(0.12), lineWidth: 1))
    }
}

extension View {
    func glass(radius: CGFloat = 16) -> some View { modifier(GlassCard(radius: radius)) }
}

struct GradientText: View {
    let text: String
    var font: Font = .title2.bold()
    var body: some View {
        Text(text).font(font).foregroundStyle(Theme.brand)
    }
}

struct BrandButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Theme.brand)
            .clipShape(Capsule())
            .opacity(configuration.isPressed ? 0.8 : 1)
    }
}

struct Chip: View {
    let title: String
    let selected: Bool
    var locked: Bool = false
    var body: some View {
        HStack(spacing: 4) {
            if locked { Image(systemName: "lock.fill").font(.caption2) }
            Text(title).font(.subheadline.weight(.medium)).lineLimit(1)
        }
        .foregroundColor(.white)
        .padding(.horizontal, 14).padding(.vertical, 8)
        .background(selected ? AnyShapeStyle(Theme.brand) : AnyShapeStyle(Color.white.opacity(0.10)))
        .clipShape(Capsule())
    }
}

struct Poster: View {
    let url: String?
    var aspect: CGFloat = 2.0 / 3.0
    var body: some View {
        ZStack {
            Color.white.opacity(0.06)
            if let s = url, !s.isEmpty, let u = URL(string: s) {
                AsyncImage(url: u) { phase in
                    switch phase {
                    case .success(let img): img.resizable().scaledToFill()
                    default: Image(systemName: "play.rectangle.fill").foregroundColor(.white.opacity(0.25))
                    }
                }
            } else {
                Image(systemName: "play.rectangle.fill").foregroundColor(.white.opacity(0.25))
            }
        }
        .aspectRatio(aspect, contentMode: .fit)
        .clipped()
    }
}
