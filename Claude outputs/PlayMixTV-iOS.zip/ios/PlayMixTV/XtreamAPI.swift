import Foundation

enum APIError: LocalizedError {
    case badResponse
    case authFailed
    case expired
    case panel(String)

    var errorDescription: String? {
        switch self {
        case .badResponse: return "Respuesta inválida del servidor."
        case .authFailed: return "Credenciales o código incorrectos."
        case .expired: return "La cuenta está vencida o desactivada."
        case .panel(let m): return m
        }
    }
}

private func str(_ v: Any?) -> String {
    if let s = v as? String { return s }
    if let n = v as? NSNumber { return n.stringValue }
    return ""
}

private func int(_ v: Any?) -> Int {
    if let n = v as? NSNumber { return n.intValue }
    if let s = v as? String { return Int(s) ?? 0 }
    return 0
}

/// Cliente mínimo de la API Xtream Codes (player_api.php).
struct XtreamAPI {
    let account: Account

    func fetch(_ action: String?, _ params: [String: String] = [:]) async throws -> Any {
        guard var comps = URLComponents(string: account.server + "/player_api.php") else {
            throw APIError.badResponse
        }
        var items = [
            URLQueryItem(name: "username", value: account.username),
            URLQueryItem(name: "password", value: account.password),
        ]
        if let action { items.append(URLQueryItem(name: "action", value: action)) }
        for (k, v) in params { items.append(URLQueryItem(name: k, value: v)) }
        comps.queryItems = items
        guard let url = comps.url else { throw APIError.badResponse }

        var req = URLRequest(url: url)
        req.timeoutInterval = 30
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard (resp as? HTTPURLResponse)?.statusCode == 200 else { throw APIError.badResponse }
        return try JSONSerialization.jsonObject(with: data)
    }

    func login() async throws {
        let json = try await fetch(nil)
        guard let dict = json as? [String: Any],
              let info = dict["user_info"] as? [String: Any] else { throw APIError.authFailed }
        guard int(info["auth"]) == 1 else { throw APIError.authFailed }
        let status = str(info["status"]).lowercased()
        if !status.isEmpty && status != "active" { throw APIError.expired }
    }

    func categories(_ kind: Kind) async throws -> [Category] {
        let action: String
        switch kind {
        case .live: action = "get_live_categories"
        case .movie: action = "get_vod_categories"
        default: action = "get_series_categories"
        }
        let json = try await fetch(action)
        let arr = json as? [[String: Any]] ?? []
        return arr.map { Category(id: str($0["category_id"]), name: str($0["category_name"])) }
    }

    func items(_ kind: Kind, category: String?) async throws -> [Media] {
        var params: [String: String] = [:]
        if let category { params["category_id"] = category }
        let action: String
        switch kind {
        case .live: action = "get_live_streams"
        case .movie: action = "get_vod_streams"
        default: action = "get_series"
        }
        let json = try await fetch(action, params)
        let arr = json as? [[String: Any]] ?? []
        return arr.map { d in
            switch kind {
            case .live:
                return Media(kind: .live, mediaId: str(d["stream_id"]), name: str(d["name"]),
                             icon: str(d["stream_icon"]), categoryId: str(d["category_id"]), ext: "m3u8")
            case .movie:
                return Media(kind: .movie, mediaId: str(d["stream_id"]), name: str(d["name"]),
                             icon: str(d["stream_icon"]), categoryId: str(d["category_id"]),
                             ext: str(d["container_extension"]), rating: str(d["rating"]))
            default:
                return Media(kind: .series, mediaId: str(d["series_id"]), name: str(d["name"]),
                             icon: str(d["cover"]), categoryId: str(d["category_id"]),
                             plot: str(d["plot"]), rating: str(d["rating"]))
            }
        }
    }

    func episodes(seriesId: String) async throws -> [Episode] {
        let json = try await fetch("get_series_info", ["series_id": seriesId])
        guard let dict = json as? [String: Any] else { return [] }
        var result: [Episode] = []

        func parse(_ list: [[String: Any]], fallbackSeason: Int) {
            for e in list {
                let info = e["info"] as? [String: Any] ?? [:]
                let season = int(e["season"]) == 0 ? fallbackSeason : int(e["season"])
                result.append(Episode(
                    id: str(e["id"]),
                    season: season,
                    number: int(e["episode_num"]),
                    title: str(e["title"]),
                    ext: str(e["container_extension"]),
                    plot: str(info["plot"]),
                    image: str(info["movie_image"])))
            }
        }

        if let byName = dict["episodes"] as? [String: Any] {
            for (key, value) in byName {
                if let list = value as? [[String: Any]] { parse(list, fallbackSeason: Int(key) ?? 1) }
            }
        } else if let lists = dict["episodes"] as? [[[String: Any]]] {
            for (i, list) in lists.enumerated() { parse(list, fallbackSeason: i + 1) }
        }
        return result.sorted { ($0.season, $0.number) < ($1.season, $1.number) }
    }
}
