import SwiftUI
import AVFoundation

@main
struct PlayMixTVApp: App {
    @StateObject private var session = Session()
    @StateObject private var catalog = Catalog()
    @StateObject private var library = Library()
    @StateObject private var parental = Parental()
    @State private var showSplash = true

    init() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
        try? AVAudioSession.sharedInstance().setActive(true)

        let nav = UINavigationBarAppearance()
        nav.configureWithTransparentBackground()
        nav.titleTextAttributes = [.foregroundColor: UIColor.white]
        nav.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        UINavigationBar.appearance().standardAppearance = nav
        UINavigationBar.appearance().scrollEdgeAppearance = nav

        let tab = UITabBarAppearance()
        tab.configureWithOpaqueBackground()
        tab.backgroundColor = UIColor(red: 0.07, green: 0.02, blue: 0.13, alpha: 1)
        UITabBar.appearance().standardAppearance = tab
        UITabBar.appearance().scrollEdgeAppearance = tab
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                if session.account == nil {
                    LoginView()
                } else {
                    RootView()
                }
                if showSplash {
                    SplashView().transition(.opacity).zIndex(1)
                }
            }
            .environmentObject(session)
            .environmentObject(catalog)
            .environmentObject(library)
            .environmentObject(parental)
            .preferredColorScheme(.dark)
            .tint(Theme.pink)
            .task {
                try? await Task.sleep(nanoseconds: 1_400_000_000)
                withAnimation(.easeOut(duration: 0.4)) { showSplash = false }
            }
        }
    }
}

struct SplashView: View {
    @State private var appear = false
    var body: some View {
        ZStack {
            BrandBackground()
            VStack(spacing: 10) {
                Image(systemName: "play.tv.fill")
                    .font(.system(size: 64))
                    .foregroundStyle(Theme.brand)
                GradientText(text: "PlayMix TV", font: .system(size: 38, weight: .heavy))
                Text("by Valtecno").font(.footnote).foregroundColor(.white.opacity(0.6))
            }
            .scaleEffect(appear ? 1 : 0.8)
            .opacity(appear ? 1 : 0)
        }
        .onAppear { withAnimation(.spring(response: 0.7, dampingFraction: 0.7)) { appear = true } }
    }
}

struct RootView: View {
    @EnvironmentObject var session: Session
    @EnvironmentObject var library: Library

    var body: some View {
        TabView {
            NavigationStack { BrowserView(kind: .live) }
                .tabItem { Label("TV", systemImage: "tv") }
            NavigationStack { BrowserView(kind: .movie) }
                .tabItem { Label("Películas", systemImage: "film") }
            NavigationStack { BrowserView(kind: .series) }
                .tabItem { Label("Series", systemImage: "rectangle.stack") }
            NavigationStack { FavoritesView() }
                .tabItem { Label("Favoritos", systemImage: "heart.fill") }
            NavigationStack { MoreView() }
                .tabItem { Label("Más", systemImage: "ellipsis.circle") }
        }
        .onAppear { library.bind(session.account?.key) }
        .onChange(of: session.account) { library.bind($0?.key) }
    }
}
