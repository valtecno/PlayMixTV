import Foundation
import SwiftUI

// MARK: - Sesión

@MainActor
final class Session: ObservableObject {
    @Published var account: Account?

    private let storeKey = "account"

    init() {
        if let data = Keychain.load(storeKey),
           let acc = try? JSONDecoder().decode(Account.self, from: data) {
            account = acc
        }
    }

    /// Paso 1: valida el código en el panel de PlayMix (devuelve usuario, contraseña y servidor reales).
    /// Paso 2: con esas credenciales conecta al panel Xtream.
    func login(code: String) async throws {
        let codigo = code.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !codigo.isEmpty else { throw APIError.panel("Ingresa tu código de acceso") }

        var comps = URLComponents(string: "https://valtecno.cl/disc/paneltv/api.php")!
        comps.queryItems = [URLQueryItem(name: "codigo", value: codigo)]
        var req = URLRequest(url: comps.url!)
        req.timeoutInterval = 30
        let (data, resp) = try await URLSession.shared.data(for: req)
        let http = (resp as? HTTPURLResponse)?.statusCode ?? 0
        let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        let mensaje = obj?["mensaje"] as? String

        guard http == 200, let obj,
              (obj["status"] as? String) == "success",
              let user = obj["usuario_real"] as? String, !user.isEmpty,
              let pass = obj["password_real"] as? String, !pass.isEmpty else {
            throw APIError.panel(mensaje ?? (http == 200 ? "Código inválido" : "Error del servidor (HTTP \(http))"))
        }

        var server = (obj["dns_servidor"] as? String)?.trimmingCharacters(in: .whitespaces) ?? ""
        if server.isEmpty { server = Server.all[0].url }
        while server.hasSuffix("/") { server.removeLast() }

        let acc = Account(server: server, username: user, password: pass)
        try await XtreamAPI(account: acc).login()
        account = acc
        if let data = try? JSONEncoder().encode(acc) { Keychain.save(storeKey, data) }
    }

    func logout() {
        account = nil
        Keychain.delete(storeKey)
    }
}

// MARK: - Catálogo (con caché en memoria)

@MainActor
final class Catalog: ObservableObject {
    private var cats: [Kind: [Category]] = [:]
    private var items: [String: [Media]] = [:]

    func reset() { cats = [:]; items = [:] }

    func categories(_ kind: Kind, account: Account) async throws -> [Category] {
        if let c = cats[kind] { return c }
        let c = try await XtreamAPI(account: account).categories(kind)
        cats[kind] = c
        return c
    }

    func items(_ kind: Kind, category: String?, account: Account) async throws -> [Media] {
        let key = "\(account.key)|\(kind.rawValue)|\(category ?? "*")"
        if let i = items[key] { return i }
        let i = try await XtreamAPI(account: account).items(kind, category: category)
        items[key] = i
        return i
    }
}

// MARK: - Favoritos e historial (separados por cuenta)

@MainActor
final class Library: ObservableObject {
    @Published private(set) var favorites: [Media] = []
    @Published private(set) var history: [Media] = []
    private var accountKey = ""

    func bind(_ key: String?) {
        accountKey = key ?? ""
        favorites = load("fav")
        history = load("hist")
    }

    private func load(_ prefix: String) -> [Media] {
        guard let data = UserDefaults.standard.data(forKey: "\(prefix).\(accountKey)"),
              let list = try? JSONDecoder().decode([Media].self, from: data) else { return [] }
        return list
    }

    private func save(_ list: [Media], _ prefix: String) {
        if let data = try? JSONEncoder().encode(list) {
            UserDefaults.standard.set(data, forKey: "\(prefix).\(accountKey)")
        }
    }

    func isFavorite(_ m: Media) -> Bool { favorites.contains { $0.id == m.id } }

    func toggleFavorite(_ m: Media) {
        if let i = favorites.firstIndex(where: { $0.id == m.id }) {
            favorites.remove(at: i)
        } else {
            favorites.insert(m, at: 0)
        }
        save(favorites, "fav")
    }

    func addHistory(_ m: Media) {
        history.removeAll { $0.id == m.id }
        history.insert(m, at: 0)
        if history.count > 60 { history = Array(history.prefix(60)) }
        save(history, "hist")
    }

    func clearHistory() {
        history = []
        save(history, "hist")
    }
}

// MARK: - Control parental y modo Niños

@MainActor
final class Parental: ObservableObject {
    @Published var pin: String { didSet { UserDefaults.standard.set(pin, forKey: "parental.pin") } }
    @Published var kidsMode: Bool { didSet { UserDefaults.standard.set(kidsMode, forKey: "parental.kids") } }
    @Published private(set) var locked: Set<String>
    private var unlocked: Set<String> = []

    static let kidsKeywords = ["niño", "nino", "kids", "kid", "infantil", "infantiles", "cartoon",
                               "dibujos", "disney", "animación", "animacion", "animation",
                               "familia", "family", "junior", "children"]

    init() {
        pin = UserDefaults.standard.string(forKey: "parental.pin") ?? ""
        kidsMode = UserDefaults.standard.bool(forKey: "parental.kids")
        locked = Set(UserDefaults.standard.stringArray(forKey: "parental.locked") ?? [])
    }

    var hasPin: Bool { !pin.isEmpty }

    private func key(_ kind: Kind, _ cat: Category) -> String { "\(kind.rawValue)|\(cat.id)" }

    func isLocked(_ kind: Kind, _ cat: Category) -> Bool {
        hasPin && locked.contains(key(kind, cat)) && !unlocked.contains(key(kind, cat))
    }

    func isMarkedLocked(_ kind: Kind, _ cat: Category) -> Bool { locked.contains(key(kind, cat)) }

    func setLocked(_ on: Bool, _ kind: Kind, _ cat: Category) {
        if on { locked.insert(key(kind, cat)) } else { locked.remove(key(kind, cat)) }
        UserDefaults.standard.set(Array(locked), forKey: "parental.locked")
    }

    func unlock(_ kind: Kind, _ cat: Category) { unlocked.insert(key(kind, cat)) }

    func allowed(_ cats: [Category]) -> [Category] {
        guard kidsMode else { return cats }
        return cats.filter { c in
            let n = c.name.lowercased()
            return Parental.kidsKeywords.contains { n.contains($0) }
        }
    }
}
