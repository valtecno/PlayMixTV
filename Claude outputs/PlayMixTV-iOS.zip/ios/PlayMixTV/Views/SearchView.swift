import SwiftUI

struct SearchView: View {
    @EnvironmentObject var session: Session
    @EnvironmentObject var catalog: Catalog
    @EnvironmentObject var library: Library
    @EnvironmentObject var parental: Parental

    @State private var query = ""
    @State private var all: [Kind: [Media]] = [:]
    @State private var loading = true
    @State private var target: PlayTarget?

    private let kinds: [Kind] = [.live, .movie, .series]

    var body: some View {
        ZStack {
            BrandBackground()
            if parental.kidsMode {
                Text("La búsqueda está desactivada en modo Niños.")
                    .foregroundColor(.white.opacity(0.6)).padding()
            } else if loading {
                VStack(spacing: 10) {
                    ProgressView().tint(.white)
                    Text("Cargando catálogo…").font(.footnote).foregroundColor(.white.opacity(0.6))
                }
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 8) {
                        ForEach(kinds, id: \.self) { k in
                            let hits = results(k)
                            if !hits.isEmpty {
                                Text(k.title).font(.headline).foregroundColor(.white)
                                    .padding(.top, 8)
                                ForEach(hits) { m in MediaRow(media: m, onPlay: play) }
                            }
                        }
                        if query.count >= 2 && kinds.allSatisfy({ results($0).isEmpty }) {
                            Text("Sin resultados").foregroundColor(.white.opacity(0.5))
                                .frame(maxWidth: .infinity).padding(.top, 40)
                        }
                    }
                    .padding(.horizontal, 16).padding(.bottom, 16)
                }
            }
        }
        .navigationTitle("Buscar")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "Canales, películas, series")
        .navigationDestination(for: Media.self) { SeriesDetailView(series: $0) }
        .task { await loadAll() }
        .fullScreenCover(item: $target) { PlayerScreen(target: $0) }
    }

    private func results(_ k: Kind) -> [Media] {
        let q = query.trimmingCharacters(in: .whitespaces)
        guard q.count >= 2 else { return [] }
        return Array((all[k] ?? []).filter { $0.name.localizedCaseInsensitiveContains(q) }.prefix(40))
    }

    private func loadAll() async {
        guard let acc = session.account, !parental.kidsMode else { loading = false; return }
        for k in kinds {
            if let items = try? await catalog.items(k, category: nil, account: acc) { all[k] = items }
        }
        loading = false
    }

    private func play(_ m: Media) {
        guard let acc = session.account, let t = acc.target(for: m) else { return }
        library.addHistory(m)
        target = t
    }
}
