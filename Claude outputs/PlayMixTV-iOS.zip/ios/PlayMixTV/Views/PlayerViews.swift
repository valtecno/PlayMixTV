import SwiftUI
import AVKit

struct PlayTarget: Identifiable {
    let id = UUID()
    let url: URL
    let title: String
}

extension Account {
    func target(for m: Media) -> PlayTarget? {
        guard let url = streamURL(for: m) else { return nil }
        return PlayTarget(url: url, title: m.name)
    }
}

/// Reproductor a pantalla completa (incluye AirPlay, Imagen en Imagen y controles nativos).
struct PlayerScreen: View {
    let target: PlayTarget
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.ignoresSafeArea()
            NativePlayer(url: target.url).ignoresSafeArea()
            Button { dismiss() } label: {
                Image(systemName: "xmark")
                    .font(.headline)
                    .padding(12)
                    .background(.ultraThinMaterial, in: Circle())
                    .foregroundColor(.white)
            }
            .padding(16)
        }
        .statusBarHidden(true)
    }
}

struct NativePlayer: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let vc = AVPlayerViewController()
        let player = AVPlayer(url: url)
        player.allowsExternalPlayback = true
        vc.player = player
        vc.allowsPictureInPicturePlayback = true
        vc.canStartPictureInPictureAutomaticallyFromInline = true
        player.play()
        return vc
    }

    func updateUIViewController(_ vc: AVPlayerViewController, context: Context) {}

    static func dismantleUIViewController(_ vc: AVPlayerViewController, coordinator: ()) {
        vc.player?.pause()
        vc.player = nil
    }
}

/// Vista simple para pintar un AVPlayer (usada en multi-pantalla).
struct PlayerLayerView: UIViewRepresentable {
    let player: AVPlayer

    final class PlayerUIView: UIView {
        override class var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }

    func makeUIView(context: Context) -> PlayerUIView {
        let v = PlayerUIView()
        v.playerLayer.videoGravity = .resizeAspect
        v.playerLayer.player = player
        return v
    }

    func updateUIView(_ uiView: PlayerUIView, context: Context) {
        if uiView.playerLayer.player !== player { uiView.playerLayer.player = player }
    }
}
