import SwiftUI

struct FavoritesView: View {
    @EnvironmentObject var session: Session
    @EnvironmentObject var library: Library

    @State private var tab = 0
    @State private var target: PlayTarget?

    private var list: [Media] { tab == 0 ? library.favorites : library.history }

    var body: some View {
        ZStack {
            BrandBackground()
            VStack(spacing: 10) {
                Picker("", selection: $tab) {
                    Text("Favoritos").tag(0)
                    Text("Historial").tag(1)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 16).padding(.top, 8)

                if list.isEmpty {
                    Spacer()
                    Text(tab == 0 ? "Aún no tienes favoritos.\nMantén pulsado un canal, película o serie para añadirlo."
                                  : "Todavía no has reproducido nada.")
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white.opacity(0.5)).padding()
                    Spacer()
                } else {
                    ScrollView {
                        LazyVStack(spacing: 8) {
                            ForEach(list) { m in MediaRow(media: m, onPlay: play) }
                        }
                        .padding(.horizontal, 16).padding(.bottom, 16)
                    }
                }
            }
        }
        .navigationTitle("Mi lista")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if tab == 1 && !library.history.isEmpty {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Borrar") { library.clearHistory() }
                }
            }
        }
        .navigationDestination(for: Media.self) { SeriesDetailView(series: $0) }
        .fullScreenCover(item: $target) { PlayerScreen(target: $0) }
    }

    private func play(_ m: Media) {
        guard let acc = session.account, let t = acc.target(for: m) else { return }
        library.addHistory(m)
        target = t
    }
}
