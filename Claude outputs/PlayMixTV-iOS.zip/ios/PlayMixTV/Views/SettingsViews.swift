import SwiftUI

// MARK: - Menú "Más"

struct MoreView: View {
    var body: some View {
        ZStack {
            BrandBackground()
            List {
                NavigationLink { SearchView() } label: { Label("Buscar", systemImage: "magnifyingglass") }
                NavigationLink { MultiScreenView() } label: { Label("Multi-pantalla (4 canales)", systemImage: "square.grid.2x2") }
                NavigationLink { SettingsView() } label: { Label("Ajustes", systemImage: "gearshape") }
            }
            .scrollContentBackground(.hidden)
            .listRowBackground(Color.white.opacity(0.08))
        }
        .navigationTitle("Más")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Ajustes

struct SettingsView: View {
    @EnvironmentObject var session: Session
    @EnvironmentObject var catalog: Catalog
    @EnvironmentObject var parental: Parental

    @State private var showCreatePin = false
    @State private var showVerifyForKids = false
    @State private var showVerifyForRemove = false
    @State private var showVerifyForLocks = false
    @State private var goLocks = false

    var body: some View {
        ZStack {
            BrandBackground()
            List {
                Section("Cuenta") {
                    row("Sesión", "Activa")
                    Button("Cerrar sesión", role: .destructive) {
                        catalog.reset()
                        session.logout()
                    }
                }

                Section("Control parental") {
                    if parental.hasPin {
                        Button("Cambiar PIN") { showCreatePin = true }
                        Button("Quitar PIN", role: .destructive) { showVerifyForRemove = true }
                    } else {
                        Button("Crear PIN") { showCreatePin = true }
                    }

                    Toggle("Modo Niños", isOn: Binding(
                        get: { parental.kidsMode },
                        set: { on in
                            if !on && parental.hasPin { showVerifyForKids = true } else { parental.kidsMode = on }
                        }))

                    Button {
                        if parental.hasPin { showVerifyForLocks = true } else { showCreatePin = true }
                    } label: {
                        HStack {
                            Text("Categorías bloqueadas")
                            Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundColor(.white.opacity(0.4))
                        }
                    }
                    .foregroundColor(.white)
                }

                Section {
                    Text("El modo Niños muestra solo categorías infantiles. Las categorías bloqueadas piden el PIN para abrirse.")
                        .font(.footnote).foregroundColor(.white.opacity(0.55))
                }

                Section("Acerca de") {
                    row("Versión", Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0")
                    row("Desarrollado por", "Valtecno")
                }
            }
            .scrollContentBackground(.hidden)
            .listRowBackground(Color.white.opacity(0.08))
        }
        .navigationTitle("Ajustes")
        .navigationBarTitleDisplayMode(.inline)
        .navigationDestination(isPresented: $goLocks) { LockedCategoriesView() }
        .sheet(isPresented: $showCreatePin) { PinSheet(mode: .create) { showCreatePin = false } }
        .sheet(isPresented: $showVerifyForKids) {
            PinSheet(mode: .verify) { parental.kidsMode = false; showVerifyForKids = false }
        }
        .sheet(isPresented: $showVerifyForRemove) {
            PinSheet(mode: .verify) { parental.pin = ""; showVerifyForRemove = false }
        }
        .sheet(isPresented: $showVerifyForLocks) {
            PinSheet(mode: .verify) { showVerifyForLocks = false; goLocks = true }
        }
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title)
            Spacer()
            Text(value).foregroundColor(.white.opacity(0.6))
        }
    }
}

// MARK: - Bloqueo de categorías

struct LockedCategoriesView: View {
    @EnvironmentObject var session: Session
    @EnvironmentObject var catalog: Catalog
    @EnvironmentObject var parental: Parental

    @State private var kind: Kind = .live
    @State private var cats: [Category] = []
    @State private var loading = true

    var body: some View {
        ZStack {
            BrandBackground()
            VStack {
                Picker("", selection: $kind) {
                    Text("TV").tag(Kind.live)
                    Text("Películas").tag(Kind.movie)
                    Text("Series").tag(Kind.series)
                }
                .pickerStyle(.segmented).padding()

                if loading {
                    Spacer(); ProgressView().tint(.white); Spacer()
                } else {
                    List(cats) { c in
                        Toggle(c.name, isOn: Binding(
                            get: { parental.isMarkedLocked(kind, c) },
                            set: { parental.setLocked($0, kind, c) }))
                    }
                    .scrollContentBackground(.hidden)
                    .listRowBackground(Color.white.opacity(0.08))
                }
            }
        }
        .navigationTitle("Categorías bloqueadas")
        .navigationBarTitleDisplayMode(.inline)
        .task(id: kind) {
            loading = true
            if let acc = session.account {
                cats = (try? await catalog.categories(kind, account: acc)) ?? []
            }
            loading = false
        }
    }
}

// MARK: - PIN

struct PinSheet: View {
    enum Mode { case verify, create }

    let mode: Mode
    let onSuccess: () -> Void

    @EnvironmentObject var parental: Parental
    @Environment(\.dismiss) private var dismiss
    @State private var pin = ""
    @State private var confirm = ""
    @State private var error: String?

    var body: some View {
        NavigationStack {
            ZStack {
                BrandBackground()
                VStack(spacing: 18) {
                    Image(systemName: "lock.fill").font(.system(size: 40)).foregroundStyle(Theme.brand)
                    Text(mode == .verify ? "Ingresa tu PIN" : "Crea un PIN de 4 dígitos")
                        .font(.headline).foregroundColor(.white)

                    SecureField("PIN", text: $pin)
                        .keyboardType(.numberPad).multilineTextAlignment(.center)
                        .padding(14).glass()
                        .onChange(of: pin) { pin = String($0.filter(\.isNumber).prefix(4)) }

                    if mode == .create {
                        SecureField("Repetir PIN", text: $confirm)
                            .keyboardType(.numberPad).multilineTextAlignment(.center)
                            .padding(14).glass()
                            .onChange(of: confirm) { confirm = String($0.filter(\.isNumber).prefix(4)) }
                    }

                    if let error { Text(error).font(.footnote).foregroundColor(Theme.pink) }

                    Button("Aceptar", action: submit).buttonStyle(BrandButtonStyle())
                    Spacer()
                }
                .padding(24)
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
            }
        }
    }

    private func submit() {
        switch mode {
        case .verify:
            if pin == parental.pin { onSuccess() } else { error = "PIN incorrecto"; pin = "" }
        case .create:
            guard pin.count == 4 else { error = "El PIN debe tener 4 dígitos"; return }
            guard pin == confirm else { error = "Los PIN no coinciden"; return }
            parental.pin = pin
            onSuccess()
        }
    }
}
