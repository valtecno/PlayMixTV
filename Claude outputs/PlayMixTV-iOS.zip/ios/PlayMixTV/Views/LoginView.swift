import SwiftUI

struct LoginView: View {
    @EnvironmentObject var session: Session
    @State private var code = ""
    @State private var loading = false
    @State private var error: String?

    var body: some View {
        ZStack {
            BrandBackground()
            ScrollView {
                VStack(spacing: 22) {
                    Image(systemName: "play.tv.fill")
                        .font(.system(size: 60))
                        .foregroundStyle(Theme.brand)
                        .padding(.top, 60)
                    GradientText(text: "PlayMix TV", font: .system(size: 34, weight: .heavy))
                    Text("Ingresa tu código de acceso")
                        .font(.subheadline).foregroundColor(.white.opacity(0.65))

                    TextField("Código de acceso", text: $code)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                        .multilineTextAlignment(.center)
                        .font(.title3.weight(.semibold))
                        .padding(16)
                        .glass()
                        .submitLabel(.go)
                        .onSubmit(login)

                    if let error {
                        Text(error).font(.footnote).foregroundColor(Theme.pink)
                            .multilineTextAlignment(.center)
                    }

                    Button(action: login) {
                        if loading { ProgressView().tint(.white) } else { Text("Entrar") }
                    }
                    .buttonStyle(BrandButtonStyle())
                    .disabled(loading || code.trimmingCharacters(in: .whitespaces).isEmpty)
                    .opacity(code.trimmingCharacters(in: .whitespaces).isEmpty ? 0.5 : 1)
                }
                .padding(24)
            }
        }
    }

    private func login() {
        guard !loading else { return }
        error = nil
        loading = true
        Task {
            do { try await session.login(code: code) }
            catch { self.error = error.localizedDescription }
            loading = false
        }
    }
}
