import SwiftUI
import AVFoundation

@MainActor
final class MultiModel: ObservableObject {
    @Published var channels: [Media?] = Array(repeating: nil, count: 4)
    @Published var focus = 0
    let players: [AVPlayer] = (0..<4).map { _ in
        let p = AVPlayer()
        p.allowsExternalPlayback = true
        return p
    }

    func set(_ i: Int, _ media: Media, account: Account) {
        guard let url = account.streamURL(for: media) else { return }
        channels[i] = media
        players[i].replaceCurrentItem(with: AVPlayerItem(url: url))
        players[i].play()
        focus = i
        applyAudio()
    }

    func clear(_ i: Int) {
        channels[i] = nil
        players[i].pause()
        players[i].replaceCurrentItem(with: nil)
    }

    func setFocus(_ i: Int) {
        focus = i
        applyAudio()
    }

    func applyAudio() {
        for (i, p) in players.enumerated() { p.isMuted = (i != focus) }
    }

    func stopAll() {
        for i in 0..<4 { clear(i) }
    }
}

private struct SlotID: Identifiable { let id: Int }

struct MultiScreenView: View {
    @EnvironmentObject var session: Session
    @StateObject private var model = MultiModel()
    @State private var pick: SlotID?

    var body: some View {
        ZStack {
            BrandBackground()
            VStack(spacing: 10) {
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)],
                          spacing: 8) {
                    ForEach(0..<4, id: \.self) { i in slot(i) }
                }
                .padding(8)
                Text("Toca una pantalla vacía para elegir un canal. Toca una activa para darle el audio. Mantén pulsada para cambiar o quitar.")
                    .font(.footnote).foregroundColor(.white.opacity(0.55))
                    .multilineTextAlignment(.center).padding(.horizontal, 20)
                Spacer()
            }
        }
        .navigationTitle("Multi-pantalla")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $pick) { slotID in
            ChannelPicker { media in
                if let acc = session.account { model.set(slotID.id, media, account: acc) }
                pick = nil
            }
        }
        .onAppear { model.applyAudio() }
        .onDisappear { model.stopAll() }
    }

    @ViewBuilder
    private func slot(_ i: Int) -> some View {
        let media = model.channels[i]
        ZStack {
            Color.black
            if media != nil {
                PlayerLayerView(player: model.players[i])
                VStack {
                    HStack {
                        Text(media?.name ?? "").font(.caption2.weight(.semibold)).lineLimit(1)
                            .padding(.horizontal, 6).padding(.vertical, 3)
                            .background(.black.opacity(0.55), in: Capsule())
                        Spacer()
                        if model.focus == i {
                            Image(systemName: "speaker.wave.2.fill").font(.caption2)
                                .padding(5).background(.black.opacity(0.55), in: Circle())
                        }
                    }
                    Spacer()
                }
                .foregroundColor(.white).padding(6)
            } else {
                Image(systemName: "plus.circle").font(.largeTitle).foregroundColor(.white.opacity(0.35))
            }
        }
        .aspectRatio(16.0 / 9.0, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .overlay(RoundedRectangle(cornerRadius: 10)
            .stroke(model.focus == i ? AnyShapeStyle(Theme.brand) : AnyShapeStyle(Color.white.opacity(0.12)),
                    lineWidth: model.focus == i ? 3 : 1))
        .onTapGesture {
            if media == nil { pick = SlotID(id: i) } else { model.setFocus(i) }
        }
        .contextMenu {
            Button("Cambiar canal") { pick = SlotID(id: i) }
            if media != nil {
                Button("Quitar", role: .destructive) { model.clear(i) }
            }
        }
    }
}

/// Selector de canal en vivo para multi-pantalla.
struct ChannelPicker: View {
    let onPick: (Media) -> Void

    @EnvironmentObject var session: Session
    @EnvironmentObject var catalog: Catalog
    @EnvironmentObject var parental: Parental
    @Environment(\.dismiss) private var dismiss

    @State private var categories: [Category] = []
    @State private var selected: Category?
    @State private var items: [Media] = []
    @State private var query = ""
    @State private var loading = true

    private var filtered: [Media] {
        query.isEmpty ? items : items.filter { $0.name.localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                BrandBackground()
                VStack(spacing: 0) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(categories) { c in
                                Button { choose(c) } label: { Chip(title: c.name, selected: selected == c) }
                            }
                        }
                        .padding(.horizontal, 16).padding(.vertical, 10)
                    }
                    if loading {
                        Spacer(); ProgressView().tint(.white); Spacer()
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 8) {
                                ForEach(filtered) { m in
                                    Button { onPick(m) } label: {
                                        HStack(spacing: 12) {
                                            Poster(url: m.icon, aspect: 1).frame(width: 44, height: 44)
                                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                            Text(m.name).foregroundColor(.white).lineLimit(2)
                                            Spacer()
                                        }
                                        .padding(8).glass()
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(.horizontal, 16)
                        }
                    }
                }
            }
            .navigationTitle("Elegir canal")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() } }
            }
            .task { await loadCategories() }
        }
    }

    private func visible(_ all: [Category]) -> [Category] {
        parental.allowed(all).filter { !parental.isMarkedLocked(.live, $0) || !parental.hasPin }
    }

    private func loadCategories() async {
        guard let acc = session.account else { return }
        do {
            categories = visible(try await catalog.categories(.live, account: acc))
            if let first = categories.first {
                selected = first
                items = try await catalog.items(.live, category: first.id, account: acc)
            }
        } catch {}
        loading = false
    }

    private func choose(_ c: Category) {
        guard let acc = session.account else { return }
        selected = c
        loading = true
        Task {
            items = (try? await catalog.items(.live, category: c.id, account: acc)) ?? []
            loading = false
        }
    }
}
