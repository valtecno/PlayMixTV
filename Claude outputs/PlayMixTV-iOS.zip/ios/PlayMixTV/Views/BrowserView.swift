import SwiftUI

/// Pantalla genérica para TV en vivo, Películas y Series: categorías + contenido.
struct BrowserView: View {
    let kind: Kind

    @EnvironmentObject var session: Session
    @EnvironmentObject var catalog: Catalog
    @EnvironmentObject var library: Library
    @EnvironmentObject var parental: Parental

    @State private var categories: [Category] = []
    @State private var selected: Category?
    @State private var items: [Media] = []
    @State private var loading = false
    @State private var error: String?
    @State private var query = ""
    @State private var target: PlayTarget?
    @State private var pendingLock: Category?

    private var filtered: [Media] {
        let q = query.trimmingCharacters(in: .whitespaces)
        return q.isEmpty ? items : items.filter { $0.name.localizedCaseInsensitiveContains(q) }
    }

    var body: some View {
        ZStack {
            BrandBackground()
            VStack(spacing: 0) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(categories) { c in
                            Button { choose(c) } label: {
                                Chip(title: c.name, selected: selected == c,
                                     locked: parental.isLocked(kind, c))
                            }
                        }
                    }
                    .padding(.horizontal, 16).padding(.vertical, 10)
                }
                content
            }
        }
        .navigationTitle(kind.title)
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .automatic),
                    prompt: "Buscar en la categoría")
        .toolbar {
            if kind == .live {
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink { MultiScreenView() } label: { Image(systemName: "square.grid.2x2") }
                }
            }
        }
        .navigationDestination(for: Media.self) { SeriesDetailView(series: $0) }
        .task(id: parental.kidsMode) { await loadCategories() }
        .fullScreenCover(item: $target) { PlayerScreen(target: $0) }
        .sheet(item: $pendingLock) { cat in
            PinSheet(mode: .verify) {
                parental.unlock(kind, cat)
                pendingLock = nil
                choose(cat)
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        if loading {
            Spacer(); ProgressView().tint(.white); Spacer()
        } else if let error {
            Spacer()
            VStack(spacing: 12) {
                Text(error).multilineTextAlignment(.center).foregroundColor(.white.opacity(0.7))
                Button("Reintentar") { Task { await loadCategories() } }.buttonStyle(.bordered)
            }.padding()
            Spacer()
        } else if filtered.isEmpty {
            Spacer()
            Text(selected == nil ? "Sin categorías disponibles" : "Sin resultados")
                .foregroundColor(.white.opacity(0.5))
            Spacer()
        } else if kind == .live {
            ScrollView {
                LazyVStack(spacing: 8) {
                    ForEach(filtered) { m in
                        MediaRow(media: m, onPlay: play)
                    }
                }
                .padding(.horizontal, 16).padding(.bottom, 16)
            }
        } else {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 105), spacing: 12)], spacing: 14) {
                    ForEach(filtered) { m in
                        PosterCell(media: m, onPlay: play)
                    }
                }
                .padding(.horizontal, 16).padding(.bottom, 16)
            }
        }
    }

    private func loadCategories() async {
        guard let acc = session.account else { return }
        loading = true
        error = nil
        do {
            let all = try await catalog.categories(kind, account: acc)
            categories = parental.allowed(all)
            if let first = categories.first(where: { !parental.isLocked(kind, $0) }) {
                selected = first
                items = try await catalog.items(kind, category: first.id, account: acc)
            } else {
                selected = nil
                items = []
            }
        } catch {
            self.error = "No se pudo cargar: \(error.localizedDescription)"
        }
        loading = false
    }

    private func choose(_ c: Category) {
        if parental.isLocked(kind, c) { pendingLock = c; return }
        guard let acc = session.account else { return }
        selected = c
        query = ""
        loading = true
        error = nil
        Task {
            do { items = try await catalog.items(kind, category: c.id, account: acc) }
            catch { self.error = "No se pudo cargar: \(error.localizedDescription)" }
            loading = false
        }
    }

    private func play(_ m: Media) {
        guard let acc = session.account, let t = acc.target(for: m) else { return }
        library.addHistory(m)
        target = t
    }
}

// MARK: - Celdas reutilizables

struct MediaRow: View {
    let media: Media
    let onPlay: (Media) -> Void
    @EnvironmentObject var library: Library

    var body: some View {
        let row = HStack(spacing: 12) {
            Poster(url: media.icon, aspect: 1)
                .frame(width: 52, height: 52)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            VStack(alignment: .leading, spacing: 2) {
                Text(media.name).font(.body.weight(.medium)).foregroundColor(.white).lineLimit(2)
                Text(media.kind.title).font(.caption).foregroundColor(.white.opacity(0.5))
            }
            Spacer()
            if library.isFavorite(media) {
                Image(systemName: "heart.fill").foregroundColor(Theme.pink)
            }
            Image(systemName: media.kind == .series ? "chevron.right" : "play.fill")
                .foregroundColor(.white.opacity(0.5))
        }
        .padding(10)
        .glass()
        .contextMenu {
            Button {
                library.toggleFavorite(media)
            } label: {
                Label(library.isFavorite(media) ? "Quitar de favoritos" : "Añadir a favoritos",
                      systemImage: library.isFavorite(media) ? "heart.slash" : "heart")
            }
        }

        if media.kind == .series {
            NavigationLink(value: media) { row }.buttonStyle(.plain)
        } else {
            Button { onPlay(media) } label: { row }.buttonStyle(.plain)
        }
    }
}

struct PosterCell: View {
    let media: Media
    let onPlay: (Media) -> Void
    @EnvironmentObject var library: Library

    var body: some View {
        let cell = VStack(alignment: .leading, spacing: 6) {
            Poster(url: media.icon)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(alignment: .topTrailing) {
                    if library.isFavorite(media) {
                        Image(systemName: "heart.fill").font(.caption)
                            .foregroundColor(Theme.pink).padding(6)
                    }
                }
            Text(media.name).font(.caption.weight(.medium)).foregroundColor(.white)
                .lineLimit(2).multilineTextAlignment(.leading)
        }
        .contextMenu {
            Button {
                library.toggleFavorite(media)
            } label: {
                Label(library.isFavorite(media) ? "Quitar de favoritos" : "Añadir a favoritos",
                      systemImage: library.isFavorite(media) ? "heart.slash" : "heart")
            }
        }

        if media.kind == .series {
            NavigationLink(value: media) { cell }.buttonStyle(.plain)
        } else {
            Button { onPlay(media) } label: { cell }.buttonStyle(.plain)
        }
    }
}
