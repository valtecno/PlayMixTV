import SwiftUI

struct SeriesDetailView: View {
    let series: Media

    @EnvironmentObject var session: Session
    @EnvironmentObject var library: Library

    @State private var episodes: [Episode] = []
    @State private var season = 1
    @State private var loading = true
    @State private var error: String?
    @State private var target: PlayTarget?

    private var seasons: [Int] { Array(Set(episodes.map(\.season))).sorted() }

    var body: some View {
        ZStack {
            BrandBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    HStack(alignment: .top, spacing: 14) {
                        Poster(url: series.icon)
                            .frame(width: 110)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        VStack(alignment: .leading, spacing: 8) {
                            Text(series.name).font(.title3.bold()).foregroundColor(.white)
                            if !series.rating.isEmpty, series.rating != "0" {
                                Label(series.rating, systemImage: "star.fill")
                                    .font(.caption).foregroundColor(Theme.orange)
                            }
                            if !series.plot.isEmpty {
                                Text(series.plot).font(.footnote)
                                    .foregroundColor(.white.opacity(0.7)).lineLimit(6)
                            }
                        }
                    }

                    if loading {
                        ProgressView().tint(.white).frame(maxWidth: .infinity).padding(.top, 30)
                    } else if let error {
                        Text(error).foregroundColor(.white.opacity(0.7))
                    } else {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(seasons, id: \.self) { s in
                                    Button { season = s } label: {
                                        Chip(title: "Temporada \(s)", selected: season == s)
                                    }
                                }
                            }
                        }
                        ForEach(episodes.filter { $0.season == season }) { ep in
                            Button { play(ep) } label: {
                                HStack(spacing: 12) {
                                    Text("\(ep.number)")
                                        .font(.headline).foregroundStyle(Theme.brand)
                                        .frame(width: 34)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(ep.title.isEmpty ? "Episodio \(ep.number)" : ep.title)
                                            .font(.subheadline.weight(.medium))
                                            .foregroundColor(.white).lineLimit(2)
                                            .multilineTextAlignment(.leading)
                                        if !ep.plot.isEmpty {
                                            Text(ep.plot).font(.caption)
                                                .foregroundColor(.white.opacity(0.55)).lineLimit(2)
                                                .multilineTextAlignment(.leading)
                                        }
                                    }
                                    Spacer()
                                    Image(systemName: "play.fill").foregroundColor(.white.opacity(0.6))
                                }
                                .padding(12)
                                .glass()
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .padding(16)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button { library.toggleFavorite(series) } label: {
                    Image(systemName: library.isFavorite(series) ? "heart.fill" : "heart")
                }
            }
        }
        .task { await load() }
        .fullScreenCover(item: $target) { PlayerScreen(target: $0) }
    }

    private func load() async {
        guard let acc = session.account else { return }
        do {
            episodes = try await XtreamAPI(account: acc).episodes(seriesId: series.mediaId)
            season = seasons.first ?? 1
            if episodes.isEmpty { error = "Esta serie no tiene episodios disponibles." }
        } catch {
            self.error = "No se pudo cargar: \(error.localizedDescription)"
        }
        loading = false
    }

    private func play(_ ep: Episode) {
        guard let acc = session.account else { return }
        let m = Media(kind: .episode, mediaId: ep.id,
                      name: "\(series.name) T\(ep.season)E\(ep.number)",
                      icon: series.icon, ext: ep.ext)
        guard let t = acc.target(for: m) else { return }
        library.addHistory(m)
        target = t
    }
}
