import Foundation

enum Kind: String, Codable, CaseIterable {
    case live, movie, series, episode

    var title: String {
        switch self {
        case .live: return "TV en vivo"
        case .movie: return "Películas"
        case .series: return "Series"
        case .episode: return "Episodios"
        }
    }
}

struct Category: Identifiable, Hashable {
    let id: String
    let name: String
}

/// Elemento genérico del catálogo (canal, película, serie o episodio).
struct Media: Identifiable, Hashable, Codable {
    var kind: Kind
    var mediaId: String
    var name: String
    var icon: String?
    var categoryId: String = ""
    var ext: String = ""
    var plot: String = ""
    var rating: String = ""

    var id: String { "\(kind.rawValue)|\(mediaId)" }
}

struct Server: Identifiable, Hashable {
    let name: String
    let url: String
    var id: String { url }

    static let all = [
        Server(name: "Sistema L", url: "http://xdplayer.tv:8080"),
        Server(name: "Sistema XL", url: "http://moontools.site:8080"),
    ]
}

struct Account: Codable, Equatable {
    var server: String
    var username: String
    var password: String

    /// Clave para separar favoritos e historial por cuenta.
    var key: String { "\(server)|\(username)" }

    var serverName: String { Server.all.first { $0.url == server }?.name ?? server }

    private func enc(_ s: String) -> String {
        s.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? s
    }

    func streamURL(for m: Media) -> URL? {
        let u = enc(username), p = enc(password)
        switch m.kind {
        case .live:
            return URL(string: "\(server)/live/\(u)/\(p)/\(m.mediaId).m3u8")
        case .movie:
            return URL(string: "\(server)/movie/\(u)/\(p)/\(m.mediaId).\(m.ext.isEmpty ? "mp4" : m.ext)")
        case .episode:
            return URL(string: "\(server)/series/\(u)/\(p)/\(m.mediaId).\(m.ext.isEmpty ? "mp4" : m.ext)")
        case .series:
            return nil
        }
    }
}

struct Episode: Identifiable, Hashable {
    let id: String
    let season: Int
    let number: Int
    let title: String
    let ext: String
    let plot: String
    let image: String?
}
